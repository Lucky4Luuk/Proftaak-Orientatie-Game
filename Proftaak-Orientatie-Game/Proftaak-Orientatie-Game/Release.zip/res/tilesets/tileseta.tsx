<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="tilesetatest" tilewidth="16" tileheight="16" tilecount="100" columns="10">
 <image source="tileseta.PNG" width="160" height="160"/>
</tileset>